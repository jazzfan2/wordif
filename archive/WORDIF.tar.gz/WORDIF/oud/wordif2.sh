#!/bin/bash
# Name: wordif2.sh
# Author: Rob Toscani
# Date: 8th December 2025
# Description: This program is a wrapper-script around 'wdiff()'
# (https://www.gnu.org/software/wdiff/), performing word-by-word
# comparison between two plain-text-files.
#
# It does either:
# a. one single comparison between given two text-files, or
# b. (optionally) multiple comparison of all pairs of text-files
#     with equally numbered name, shared by given two directories.
#
# The results are stored as color-marked difference-files in HTML-,
# or (optionally) PDF-format.
#
# Usage:  wordif2.sh   [-p]  FILE1       FILE2
#         wordif2.sh -d[-p]  DIRECTORY1  DIRECTORY2
# Options:
#   -h    Help (this output)
#   -d    Specify two directories as arguments instead of two files;
#         Compare each file in directory2 to the equally unique-numbered file in
#         directory1
#   -p    Output as PDF- instead of HTML-files
#
# Prerequisites:
# - wdiff
# - wkhtmltopdf (if output to PDF is desired)
#
#####################################################################################
#
# Copyright (C) 2025 Rob Toscani <rob_toscani@yahoo.com>
#
# wordif2.sh is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# wordif2.sh is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
######################################################################################

# Standard arguments:
args="files"

# The color markings:
delete_start="<span style=\"font-weight:bold;color:#ff0000;\">"
insert_start="<span style=\"font-weight:bold;color:#00ff00;\">"
end="</span>"

# Escape < and > to prevent interpretation as HTML-syntax (tags):
esc_html="s/</\&lt;/g; s/>/\&gt;/g"

# The HTML-tags to be pasted underneath the text:
html_coda="
</pre>
</body>
</html>"

# Standard output-directory:
outputdir="./"

# Standard output-format:
format="html"


# FUNCTIONS:
# ==========

options(){
# Specify options:
    while getopts "dhp" OPTION; do
        case $OPTION in
            d) args="directories"
               ;;
            h) helptext
               exit 0
               ;;
            p) format="pdf"
               ;;
            *) helptext
               exit 1
               ;;
        esac
    done
}

helptext()
# Text printed if -h option (help) or a non-existent option has been given:
{
    while read "line"; do
        echo "$line" >&2         # print to standard error (stderr)
    done << EOF
Usage: 
|        wordif2.sh   [-p]  FILE1       FILE2
|        wordif2.sh -d[-p]  DIRECTORY1  DIRECTORY2
|
|-h      Help (this output)
|-d      Specify two directories as arguments instead of two files;
|        Compare each file in directory2 to the equally unique-numbered file in directory1
|-p      Output as PDF- instead of HTML-files
EOF
}

numberlist()
# Print a ('horizontal') list of the leading numbers in the file names in given directory:
{
    ls "$1"           |
    grep -oE ^[0-9]+_ |
    tr '_' ' '        |
    sort -n           |
    tr -d '\n'        |
    sed 's/ $//'
}

checkrepeat()
# Detect any repeating numbers in a sorted number list, and issue a warning if found:
{
    repeatnum="$(\
    awk '{ for (f = 2; f <= NF; f++)
               if ($f == $(f-1) && $f != prevprint){
                   printf $f" "
                   prevprint = $f
               }
    }' <<< "$1" )"
    if [[ -n "$repeatnum" ]]; then
        echo -n "WARNING: Number(s) "$repeatnum"found in more than one single file-name in directory $2. " >&2
        echo    "Per mentioned number, most files compare to a wrong file in directory $3." >&2
    fi
}

is_plain_text()
# Verify if both files contain plain text only, and if not issue an error message:
{
    if LC_ALL=C.UTF-8 grep -avxq '.*' "$1" || LC_ALL=C.UTF-8 grep -avxq '.*' "$2"; then
        echo "ERROR: Other than plain text in $1 and/or $2 or can't be evaluated, skipping."
        return 1
    fi
    return 0
}

makediff()
# Perform text comparison between two text files, and store the output in desired format:
{
    NUMBER="$3"
    if  [[ $args == "directories" ]]; then
        # If option = -d (directories), derive both file names from given directories and <NUMBER>:
        file1="$(ls $1/$NUMBER"_"* 2>/dev/null | head -n 1)"
        file2="$(ls $2/$NUMBER"_"* 2>/dev/null | head -n 1)"

        # Do nothing if a <NUMBER> is missing. and issue warning if it misses in one directory only:
        if ([[ -z "$file1" ]] || [[ -z "$file2" ]]); then
            if [[ -n "$file1" ]]; then
                echo "WARNING: Number $NUMBER appears in directory 1 only, not in directory 2."
            elif [[ -n "$file2" ]]; then
                echo "WARNING: Number $NUMBER appears in directory 2 only, not in directory 1."
            fi
            return
        fi
    else
        # If arguments are supposed to be files, verify that no directories are being given:
        if [[ ! -d "$1" ]] && [[ ! -d "$2" ]]; then
            file1="$1"
            file2="$2"
        else
            echo "ERROR: Do not specify directories"
            return 1
        fi
    fi

    # The HTML-tags to be pasted above the text:
    html_intro="
<!DOCTYPE html>
<html>
<head>
<meta charset=\"utf8\">
<style type=\"text/css\">
pre {
  font-family:Courier New;
  font-size:12pt;
  white-space: pre-wrap;
  white-space: -moz-pre-wrap;
  white-space: -pre-wrap;
  white-space: -o-pre-wrap;
  white-space: -webkit-pre-wrap;
  word-wrap: break-word;
}
</style>
<title>$file2</title>
</head>
<body>
<pre>"

    # If both files are indeed plain text, compare them to each other:
    if is_plain_text "$file1" "$file2"; then
        # Generate the color-marked difference-file:
#       wdiff -w "$delete_start" -x "$end" -y "$insert_start" -z "$end" \
#                 <(sed "$esc_html" "$file1") <(sed "$esc_html" "$file2") |

#       wdiffer.py -w "$delete_start" -x "$end" -y "$insert_start" -z "$end" \
#                       <(sed "$esc_html" "$file1") <(sed "$esc_html" "$file2") |

        wdiffer.sh -w "$delete_start" -x "$end" -y "$insert_start" -z "$end" \
                      <(sed "$esc_html" "$file1") <(sed "$esc_html" "$file2") |

        # And save results in desired format (default HTML):
        cat <(echo "$html_intro") - <(echo "$html_coda") | store2file - $NUMBER
    fi
}

store2file()
# Store text stream to HTML-file, or (if option -p is given) convert to PDF-file:
{
    file="$1"
    NUMBER="$2"
    if [[ $format == "html" ]]; then
        cat "$file" >| "$outputdir"/"$(date +"%Y%m%d_%H%M")_diff_$NUMBER.html"
    else
        wkhtmltopdf "$file" "$outputdir"/"$(date +"%Y%m%d_%H%M")_diff_$NUMBER.pdf" 2>/dev/null
    fi
}


# MAIN FUNCTION:
# ==============

# Execute the options:
options "$@"
shift $(( OPTIND - 1 ))

[[ $# < 2 ]] && echo "Not enough arguments given" && exit 1

if [[ $args == "directories" ]]; then

    # Check if given directories exist:
    ([[ ! -d "$1" ]] || [[ ! -d "$2" ]]) && echo "Specify existing directories." && exit 1

    # Create the ./diff/-directory, unless it already exists:
    [[ ! -d ./diff ]] && mkdir ./diff
    outputdir="./diff"

    # Create a list with all <NUMBER> values for each of the two directories:
    list1="$(numberlist "$1")"
    list2="$(numberlist "$2")"

    # Check if the <NUMBER>-lists contain any repetitions, and if so issue a warning:
    checkrepeat "$list1" 1 2
    checkrepeat "$list2" 2 1

    # Determine the maximum <NUMBER> value appearing in any of the sorted lists:
    max1=${list1/* /}
    max2=${list2/* /}
    (( max1 > max2 )) && max=$max1 || max=$max2

    # While incrementing from 0 to max value, call makediff() function with <NUMBER> argument:
    NUMBER=0
    while (( NUMBER <= max )); do
        makediff "$1" "$2" $NUMBER
        (( NUMBER += 1 ))
    done

    # Conclusion:
    echo "READY! - Please find all results in $(pwd)/diff/"

else
    # In case of files instead of directories as arguments:
    makediff "$1" "$2"
fi
