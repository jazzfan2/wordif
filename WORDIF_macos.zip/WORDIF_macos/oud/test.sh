#!/bin/bash

awk '{ for (i = 0; i < 5800; i++){  for (j = 0; j < 5800; j++) m[i,j] = 10 }}' <<< "Boe" | cat -
